# Queimadas no Brasil em 2023

Projeto de relatório Power BI com quatro páginas: Brasil, regiões e estados, sazonalidade e Goiás.

**Situação:** dados e estrutura JSON validados. A abertura, o processamento M/DAX e a renderização no Power BI Desktop não foram executados no ambiente de criação. Faça a conferência abaixo antes de apresentar ou publicar.

## Fonte pública

- [INPE - dados anuais do satélite de referência](https://dataserver-coids.inpe.br/queimadas/queimadas/focos/csv/anual/Brasil_sat_ref/)
- [ZIP original de 2023](https://dataserver-coids.inpe.br/queimadas/queimadas/focos/csv/anual/Brasil_sat_ref/focos_br_ref_2023.zip)
- [INPE - significado e limitações dos focos](https://data.inpe.br/queimadas/pages/secao_informacoes/faq/index.html)
- [IBGE - grandes regiões](https://agenciadenoticias.ibge.gov.br/agencia-noticias/2012-agencia-de-noticias/noticias/19383-dividir-para-conhecer-as-diversas-divisoes-regionais-do-brasil)

Consulta e download: 08/10/2026. O CSV original foi preservado sem regravação. Seu SHA256 está em documentacao/validacao_dados.json.

## Como abrir

1. Extraia todas as pastas.
2. Abra powerbi/Queimadas_2023.pbip em Power BI Desktop atualizado, no Windows.
3. Se solicitado pela versão instalada, habilite projetos PBIP/PBIR nas opções de recursos de visualização e reinicie.
4. Clique em Atualizar para processar o retrato de dados incorporado.
5. Sem filtros, confira 189.901 focos no Brasil e 4.129 municípios com focos. Em Goiás: 3.160 focos e 209 municípios. Norte: 90.147. Setembro nacional: 46.486.
6. Confira as quatro páginas e retorne os filtros para Todos.
7. Salve. É possível gerar .pbix no Desktop pela opção Salvar como, quando disponível. Não renomeie .pbip para .pbix.

## Publicar na nuvem

Entre no Desktop com sua conta habilitada para Power BI. Use Página inicial > Publicar e selecione um workspace permitido. Confira o relatório e o modelo semântico em app.powerbi.com. O compartilhamento depende de licença e permissões. Publicar no workspace não o torna público.

Para um portfólio com acesso aberto, veja [Publicar na Web](https://learn.microsoft.com/pt-br/power-bi/collaborate-share/service-publish-to-web), se habilitado pelo administrador. Esse recurso disponibiliza o relatório sem autenticação. O guia PDF descreve o procedimento completo.

Não há conexão a arquivos locais nem gateway no modelo incorporado. Atualizar apenas reprocessa o retrato de 2023; não baixa dados novos do INPE.

## Dados e modelo

- dados/originais/focos_br_ref_2023.csv: 189.901 registros de focos, nove colunas originais.
- dados/tratados/focos_mensais_municipio_bioma_2023.csv: 17.603 linhas agregadas com Quantidade.
- dados/Resumo_e_dados_tratados_2023.xlsx: planilha auxiliar com resumo e base tratada, referente à versão entregue.
- powerbi/: relatório PBIR e modelo TMSL (.bim), consultas M e medidas DAX.
- documentacao/: guia PDF/texto, resultados e registros de validação.
- scripts/: download da fonte e recriação do CSV tratado e do projeto Power BI.

Região deriva do estado; mês deriva da data_pas original, sem conversão de fuso. Município/UF distingue nomes de municípios em estados diferentes. Total de focos = SUM(Focos[Quantidade]); COUNTROWS da tabela agregada é incorreto para esse indicador. Os 12 meses ficam em uma dimensão própria, com ordenação cronológica.

O modelo contém uma cópia comprimida dos dados tratados na consulta M. Os filtros de região, estado, bioma e mês são locais a cada página. A página Goiás contém filtro fixo de estado. A participação nacional preserva o período/bioma e remove filtros geográficos; a participação das tabelas usa o total do recorte.

## Resultados da versão entregue

| Região | Focos |
| --- | ---: |
| Norte | 90.147 |
| Nordeste | 56.537 |
| Centro-Oeste | 29.501 |
| Sudeste | 9.111 |
| Sul | 4.605 |

Setembro foi o pico nacional (46.486). Setembro a novembro somaram 59,50% dos focos do ano. Goiás teve 3.160 focos e pico em setembro (651).

Focos detectados não equivalem a incêndios únicos ou hectares queimados. Contagens brutas não são taxas por área. A base não permite estimar causas, risco meteorológico ou perdas econômicas.

## Reproduzir

Requer Python 3.10 ou superior. Execute na pasta do projeto:

```bash
python -m pip install -r scripts/requirements.txt
python scripts/baixar_fonte.py
python scripts/recriar_projeto.py
```

Recriar sobrescreve os arquivos do modelo e dos visuais: preserve suas edições em um commit ou cópia. A planilha Excel auxiliar não é recriada por esse script; corresponde à versão entregue. Após revisões do INPE, novos totais podem diferir. Atualize o guia, a validação e os resultados antes de republicar.

## Verificações

Zero campos vazios nas nove colunas originais; zero linhas ou identificadores de foco duplicados; todas as datas em 2023; 27 estados/DF e seis biomas. Original e tratado reconciliam por região, estado, município/UF, mês, bioma e total. 65 arquivos de definição foram validados contra 16 esquemas oficiais Microsoft, sem erros. Isso não substitui abertura e conferência visual no Desktop.

Documentação: [PBIP](https://learn.microsoft.com/pt-br/power-bi/developer/projects/projects-overview), [PBIR](https://learn.microsoft.com/pt-br/power-bi/developer/embedded/projects-enhanced-report-format), [publicação no Desktop](https://learn.microsoft.com/pt-br/power-bi/create-reports/desktop-upload-desktop-files).
