from pathlib import Path
import pandas as pd,json,zlib,base64,hashlib,shutil,uuid,zipfile
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT;OUT.mkdir(exist_ok=True)
for d in ['dados/originais','dados/tratados','powerbi/Queimadas.Report/definition/pages','powerbi/Queimadas.SemanticModel','scripts','documentacao']: (OUT/d).mkdir(parents=True,exist_ok=True)
source=ROOT/'dados/originais/focos_br_ref_2023.csv'
url='https://dataserver-coids.inpe.br/queimadas/queimadas/focos/csv/anual/Brasil_sat_ref/focos_br_ref_2023.zip'
regions={
'Norte':'ACRE|AMAPÁ|AMAZONAS|PARÁ|RONDÔNIA|RORAIMA|TOCANTINS',
'Nordeste':'ALAGOAS|BAHIA|CEARÁ|MARANHÃO|PARAÍBA|PERNAMBUCO|PIAUÍ|RIO GRANDE DO NORTE|SERGIPE',
'Centro-Oeste':'DISTRITO FEDERAL|GOIÁS|MATO GROSSO|MATO GROSSO DO SUL',
'Sudeste':'ESPÍRITO SANTO|MINAS GERAIS|RIO DE JANEIRO|SÃO PAULO',
'Sul':'PARANÁ|RIO GRANDE DO SUL|SANTA CATARINA'}
regmap={e:r for r,es in regions.items() for e in es.split('|')}
ufs='ACRE:AC,ALAGOAS:AL,AMAPÁ:AP,AMAZONAS:AM,BAHIA:BA,CEARÁ:CE,DISTRITO FEDERAL:DF,ESPÍRITO SANTO:ES,GOIÁS:GO,MARANHÃO:MA,MATO GROSSO:MT,MATO GROSSO DO SUL:MS,MINAS GERAIS:MG,PARÁ:PA,PARAÍBA:PB,PARANÁ:PR,PERNAMBUCO:PE,PIAUÍ:PI,RIO DE JANEIRO:RJ,RIO GRANDE DO NORTE:RN,RIO GRANDE DO SUL:RS,RONDÔNIA:RO,RORAIMA:RR,SANTA CATARINA:SC,SÃO PAULO:SP,SERGIPE:SE,TOCANTINS:TO'
ufmap=dict(x.split(':') for x in ufs.split(','))
months=['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
p=pd.read_csv(source);ts=pd.to_datetime(p.data_pas,errors='raise');assert ts.dt.year.eq(2023).all();assert p.foco_id.is_unique;assert p.id_bdq.is_unique;assert p.notna().all().all();assert set(p.estado)==set(regmap);assert p.lat.between(-90,90).all() and p.lon.between(-180,180).all()
p['Regiao']=p.estado.map(regmap);p['UF']=p.estado.map(ufmap);p['MesNumero']=ts.dt.month;p['MunicipioUF']=p.municipio+' / '+p.UF
keys=['Regiao','UF','estado','municipio','MunicipioUF','bioma','MesNumero']
a=p.groupby(keys,dropna=False).size().reset_index(name='Quantidade').rename(columns={'estado':'Estado','municipio':'Municipio','bioma':'Bioma'})
a['Semestre']=a.MesNumero.map(lambda x:'1º semestre' if x<=6 else '2º semestre'); a=a.sort_values(keys[:2]+['Estado','Municipio','Bioma','MesNumero'] if False else ['Regiao','UF','Municipio','Bioma','MesNumero']).reset_index(drop=True)
a.to_csv(OUT/'dados/tratados/focos_mensais_municipio_bioma_2023.csv',index=False,encoding='utf-8-sig')
assert a.Quantidade.sum()==len(p)
for col,name in [('Regiao','regioes'),('Estado','estados'),('Bioma','biomas'),('MesNumero','meses'),('MunicipioUF','municipios')]:
 orig=p.rename(columns={'estado':'Estado','bioma':'Bioma'}).groupby(col).size().sort_index();calc=a.groupby(col).Quantidade.sum().sort_index();pd.testing.assert_series_equal(orig,calc,check_names=False)
reg=p.groupby('Regiao').size().sort_values(ascending=False);monthly=p.groupby('MesNumero').size();biomas=p.groupby('bioma').size().sort_values(ascending=False);go=p[p.UF=='GO'];go_m=go.groupby('MesNumero').size().reindex(range(1,13),fill_value=0)
summary={'total':len(p),'linhas_agregadas':len(a),'municipios_com_focos':p.MunicipioUF.nunique(),'goias':len(go),'regioes':reg.to_dict(),'meses':monthly.to_dict(),'biomas':biomas.to_dict(),'goias_meses':go_m.to_dict(),'set_out_nov_pct':float(monthly.loc[[9,10,11]].sum()/len(p)*100),'goias_municipios':go.MunicipioUF.nunique(),'top_goias':go.groupby('MunicipioUF').size().sort_values(ascending=False).head(10).to_dict()}
(OUT/'documentacao/resultados_verificados.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
checks={'arquivo_original_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'fonte':url,'consulta':'2026-10-08','linhas_originais':len(p),'linhas_tratadas':len(a),'duplicados_foco_id':int(p.foco_id.duplicated().sum()),'duplicados_linha':int(p.iloc[:,:9].duplicated().sum()),'nulos_campos_originais':p.iloc[:,:9].isna().sum().to_dict(),'data_min':str(ts.min()),'data_max':str(ts.max()),'estados':p.estado.nunique(),'reconciliacoes':['total','regiao','estado','bioma','mes','municipio_uf'],'renderizado_powerbi_desktop':False}
(OUT/'documentacao/validacao_dados.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
def write(path,obj):
 path=OUT/path;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def mid():return str(uuid.uuid4())
def mexpr(rows,cols,types):
 raw=json.dumps(rows,ensure_ascii=False,separators=(',',':')).encode();co=zlib.compressobj(wbits=-15);compressed=co.compress(raw)+co.flush();encoded=base64.b64encode(compressed).decode()
 # Split long literals to avoid editor/literal length limitations.
 chunks=[encoded[i:i+24000] for i in range(0,len(encoded),24000)]
 lines=['let','    Conteudo = Text.Combine({'+','.join('"'+c+'"' for c in chunks)+'}),','    Linhas = Json.Document(Binary.Decompress(Binary.FromText(Conteudo, BinaryEncoding.Base64), Compression.Deflate)),','    Tabela = Table.FromRows(Linhas, {'+','.join('"'+c+'"' for c in cols)+'}),','    Tipos = Table.TransformColumnTypes(Tabela, {'+','.join('{"'+c+'", '+t+'}' for c,t in zip(cols,types))+'}, "pt-BR")','in','    Tipos']
 assert json.loads(zlib.decompress(base64.b64decode(encoded),wbits=-15))==rows
 return lines
cols=list(a.columns);types=['Int64.Type' if c in ['Quantidade','MesNumero'] else 'type text' for c in cols]
rows=[[int(v) if c in ['Quantidade','MesNumero'] else str(v) for c,v in zip(cols,r)] for r in a.itertuples(index=False,name=None)]
columns=[{'name':c,'dataType':'int64' if c in ['Quantidade','MesNumero'] else 'string','sourceColumn':c,'summarizeBy':'sum' if c=='Quantidade' else 'none','lineageTag':mid(),**({'isHidden':True} if c in ['Quantidade','MesNumero','MunicipioUF'] else {})} for c in cols]
measures=[
('Total de focos','COALESCE(SUM(Focos[Quantidade]), 0)','#,0','Soma das deteções de referência; unidade: focos. Não usar COUNTROWS da tabela agregada.'),
('Municípios com focos','COUNTROWS(FILTER(VALUES(Focos[MunicipioUF]), NOT ISBLANK(Focos[MunicipioUF]) && CALCULATE([Total de focos]) > 0))','#,0','Municípios presentes com detecções; chave nome + UF. Não mede a cobertura de todos os municípios do Brasil.'),
('Participação no Brasil','DIVIDE([Total de focos], CALCULATE([Total de focos], REMOVEFILTERS(Focos[Regiao], Focos[UF], Focos[Estado], Focos[Municipio], Focos[MunicipioUF])))','0.0%','Remove os filtros geográficos do denominador; mantém mês, semestre e bioma.'),
('Mês de pico','VAR T = ADDCOLUMNS(ALLSELECTED(Meses), "Qtd", CALCULATE([Total de focos])) VAR P = TOPN(1, T, [Qtd], DESC, Meses[Numero], ASC) RETURN IF([Total de focos] = 0, "Sem focos", CONCATENATEX(P, Meses[Mes], ", "))',None,'Mês de maior quantidade no recorte selecionado; empate resolvido pelo primeiro mês.'),
('Participação no recorte','DIVIDE([Total de focos], CALCULATE([Total de focos], ALLSELECTED(Focos)))','0.0%','Participação no total externo ao contexto da linha; respeita seleções da página.'),
('Focos acumulados','VAR M = MAX(Meses[Numero]) RETURN CALCULATE([Total de focos], FILTER(ALLSELECTED(Meses), Meses[Numero] <= M))','#,0','Acumulado dos meses selecionados até o mês do eixo.'),
('Fonte e limites','"INPE • Satélite de referência • 2023 | Focos detectados; não são hectares nem incêndios únicos."',None,'Nota metodológica fixa.'),
('Período e recorte','"2023 • " & IF(HASONEVALUE(Focos[Regiao]), SELECTEDVALUE(Focos[Regiao]), "Brasil / regiões selecionadas")',None,'Identifica o escopo regional em uso.')]
mt=[{'name':n,'expression':e,'description':d,'lineageTag':mid(),**({'formatString':f} if f else {})} for n,e,f,d in measures]
model={'name':'Queimadas2023','compatibilityLevel':1567,'model':{'culture':'pt-BR','sourceQueryCulture':'pt-BR','defaultPowerBIDataSourceVersion':'powerBI_V3','tables':[{'name':'Focos','lineageTag':mid(),'columns':columns,'measures':mt,'partitions':[{'name':'Snapshot_INPE_2023','mode':'import','source':{'type':'m','expression':mexpr(rows,cols,types)}}]},{'name':'Meses','lineageTag':mid(),'columns':[{'name':'Numero','dataType':'int64','sourceColumn':'Numero','summarizeBy':'none','isHidden':True,'lineageTag':mid()},{'name':'Mes','dataType':'string','sourceColumn':'Mes','sortByColumn':'Numero','summarizeBy':'none','lineageTag':mid()}],'partitions':[{'name':'Meses2023','mode':'import','source':{'type':'m','expression':mexpr([[i+1,m] for i,m in enumerate(months)],['Numero','Mes'],['Int64.Type','type text'])}}]}],'relationships':[{'name':mid(),'fromTable':'Focos','fromColumn':'MesNumero','toTable':'Meses','toColumn':'Numero','crossFilteringBehavior':'oneDirection'}],'annotations':[{'name':'PBI_QueryOrder','value':'["Focos","Meses"]'},{'name':'PBI_ProTooling','value':'["DevMode"]'}]}}
write('powerbi/Queimadas.SemanticModel/model.bim',model)
base='https://developer.microsoft.com/json-schemas/fabric/'
write('powerbi/Queimadas.SemanticModel/definition.pbism',{'$schema':base+'item/semanticModel/definitionProperties/1.0.0/schema.json','version':'1.0','settings':{}})
write('powerbi/Queimadas_2023.pbip',{'$schema':base+'pbip/pbipProperties/1.0.0/schema.json','version':'1.0','artifacts':[{'report':{'path':'Queimadas.Report'}}],'settings':{'enableAutoRecovery':True}})
write('powerbi/Queimadas.Report/definition.pbir',{'$schema':base+'item/report/definitionProperties/2.0.0/schema.json','version':'4.0','datasetReference':{'byPath':{'path':'../Queimadas.SemanticModel'}}})
write('powerbi/Queimadas.Report/definition/version.json',{'$schema':base+'item/report/definition/versionMetadata/1.0.0/schema.json','version':'2.0.0'})
theme={'name':'Queimadas Azul','dataColors':['#1768AC','#F28E2B','#37A6A6','#8A64BF','#7395AE','#E15759'],'background':'#F3F7FB','foreground':'#17324D','tableAccent':'#1768AC','textClasses':{'label':{'fontFace':'Segoe UI','fontSize':11,'color':'#17324D'},'title':{'fontFace':'Segoe UI','fontSize':14,'color':'#17324D'},'callout':{'fontFace':'Segoe UI','fontSize':28,'color':'#1768AC'}}}
write('powerbi/Queimadas.Report/StaticResources/RegisteredResources/QueimadasAzul.json',theme)
write('powerbi/Queimadas.Report/definition/report.json',{'$schema':base+'item/report/definition/report/2.0.0/schema.json','themeCollection':{'customTheme':{'name':'QueimadasAzul','reportVersionAtImport':'5.55','type':'RegisteredResources'}},'resourcePackages':[{'name':'RegisteredResources','type':'RegisteredResources','items':[{'name':'QueimadasAzul','path':'QueimadasAzul.json','type':'CustomTheme'}]}]})
def field(name,table='Focos',measure=False): return {('Measure' if measure else 'Column'):{'Expression':{'SourceRef':{'Entity':table}},'Property':name}}
def proj(name,table='Focos',measure=False):return {'field':field(name,table,measure),'queryRef':table+'.'+name,'nativeQueryRef':name,'active':True}
def lit(v):return {'expr':{'Literal':{'Value':v}}}
def fmt(v):return {'solid':{'color':lit("'"+v+"'")}}
def filt_estado():
 f=field('Estado');return {'filters':[{'name':'GoiasFixo','type':'Categorical','field':f,'filter':{'Version':2,'From':[{'Name':'f','Entity':'Focos','Type':0}],'Where':[{'Condition':{'In':{'Expressions':[{'Column':{'Expression':{'SourceRef':{'Source':'f'}},'Property':'Estado'}}],'Values':[[{'Literal':{'Value':"'GOIÁS'"}}]]}}}]},'isLockedInViewMode':True}]}
page_names=['visao_nacional','comparacao_regional','sazonalidade','goias']
write('powerbi/Queimadas.Report/definition/pages/pages.json',{'$schema':base+'item/report/definition/pagesMetadata/1.0.0/schema.json','pageOrder':page_names,'activePageName':page_names[0]})
visual_count=0
for idx,(name,title) in enumerate(zip(page_names,['01 | Brasil • 2023','02 | Regiões e estados','03 | Sazonalidade e biomas','04 | Goiás'])):
 page={'$schema':base+'item/report/definition/page/2.0.0/schema.json','name':name,'displayName':title,'displayOption':'FitToPage','width':1440,'height':900}
 if name=='goias':page['filterConfig']=filt_estado()
 write(f'powerbi/Queimadas.Report/definition/pages/{name}/page.json',page)
 n=0
 def visual(typ,title,x,y,w,h,roles,sort=None,objects=None):
  global visual_count
  nonlocal_dummy=None
  nstr=f'v{visual_count:03d}';visual_count+=1
  q={'queryState':{k:{'projections':v} for k,v in roles.items()}}
  if sort:q['sortDefinition']={'sort':[{'field':sort[0],'direction':sort[1]}],'isDefaultSort':False}
  config={'visualType':typ,'query':q,'visualContainerObjects':{'title':[{'properties':{'show':lit('true'),'text':lit("'"+title.replace("'","''")+"'"),'fontSize':lit('14D'),'fontColor':fmt('#17324D'),'bold':lit('true')}}],'background':[{'properties':{'show':lit('true'),'color':fmt('#FFFFFF'),'transparency':lit('0D')}}]}}
  if objects:config['objects']=objects
  write(f'powerbi/Queimadas.Report/definition/pages/{name}/visuals/{nstr}/visual.json',{'$schema':base+'item/report/definition/visualContainer/2.1.0/schema.json','name':nstr,'position':{'x':x,'y':y,'width':w,'height':h,'z':visual_count,'tabOrder':visual_count},'visual':config})
 def card(title,measure,x,w=330,y=160,h=100):visual('card',title,x,y,w,h,{'Values':[proj(measure,measure=True)]})
 def slicer(title,col,x,table='Focos'):visual('slicer',title,x,60,330,85,{'Values':[proj(col,table)]},objects={'data':[{'properties':{'mode':lit("'Dropdown'")}}]})
 def chart(typ,title,col,x,y,w,h,series=None,measure='Total de focos',table='Focos',asc=False):
  roles={'Category':[proj(col,table)],'Y':[proj(measure,measure=True)]}
  if series:roles['Series']=[proj(series)]
  visual(typ,title,x,y,w,h,roles,sort=(field(col,table) if asc else field(measure,measure=True),'Ascending' if asc else 'Descending'))
 visual('card','QUEIMADAS | '+title,24,8,1392,44,{'Values':[proj('Período e recorte',measure=True)]})
 if name=='goias':
  slicer('Município','Municipio',24);slicer('Bioma','Bioma',378);slicer('Mês','Mes',732,'Meses');slicer('Semestre','Semestre',1086)
 else:
  slicer('Região','Regiao',24);slicer('Estado','Estado',378);slicer('Bioma','Bioma',732);slicer('Mês','Mes',1086,'Meses')
 card('Focos detectados','Total de focos',24);card('Municípios com focos','Municípios com focos',378);card('Mês de pico no recorte','Mês de pico',732);card('% Brasil • mesmo mês/bioma','Participação no Brasil',1086)
 if name=='visao_nacional':
  chart('clusteredBarChart','Focos por região','Regiao',24,280,560,250)
  chart('clusteredColumnChart','Distribuição mensal','Mes',604,280,812,250,table='Meses',asc=True)
  chart('clusteredBarChart','Estados por volume de focos','Estado',24,550,812,270)
  chart('donutChart','Focos por bioma','Bioma',856,550,560,270)
 elif name=='comparacao_regional':
  chart('lineChart','Meses por região • comparação simultânea','Mes',24,280,860,330,series='Regiao',table='Meses',asc=True)
  chart('clusteredBarChart','Volume por região','Regiao',904,280,512,330)
  visual('tableEx','Detalhamento geográfico • ordenado por focos',24,630,1392,190,{'Values':[proj('Regiao'),proj('UF'),proj('Municipio'),proj('Total de focos',measure=True),proj('Participação no recorte',measure=True)]},sort=(field('Total de focos',measure=True),'Descending'))
 elif name=='sazonalidade':
  chart('lineChart','Volume mensal e acumulado','Mes',24,280,860,280,table='Meses',asc=True) # accumulated separate for compatible scales
  chart('donutChart','Distribuição semestral','Semestre',904,280,512,280)
  chart('lineChart','Trajetórias por bioma','Mes',24,580,860,240,series='Bioma',table='Meses',asc=True)
  chart('clusteredBarChart','Acumulado por mês • meses selecionados','Mes',904,580,512,240,table='Meses',measure='Focos acumulados',asc=True)
 else:
  chart('clusteredColumnChart','Goiás • focos por mês','Mes',24,280,860,270,table='Meses',asc=True)
  chart('donutChart','Goiás • distribuição por bioma','Bioma',904,280,512,270)
  visual('tableEx','Goiás • municípios por volume de focos',24,570,860,250,{'Values':[proj('Municipio'),proj('Total de focos',measure=True),proj('Participação no recorte',measure=True)]},sort=(field('Total de focos',measure=True),'Descending'))
  chart('clusteredBarChart','Goiás • distribuição semestral','Semestre',904,570,512,250)
 visual('card','Fonte e interpretação',24,838,1392,46,{'Values':[proj('Fonte e limites',measure=True)]})
# Correct first seasonality title; accumulation has a separate chart.
for f in (OUT/'powerbi/Queimadas.Report/definition/pages/sazonalidade/visuals').glob('*/visual.json'):
 d=json.loads(f.read_text());t=d['visual']['visualContainerObjects']['title'][0]['properties']['text']['expr']['Literal']['Value']
 if t=="'Volume mensal e acumulado'":d['visual']['visualContainerObjects']['title'][0]['properties']['text']=lit("'Volume mensal'");f.write_text(json.dumps(d,ensure_ascii=False,indent=2))
(OUT/'powerbi/medidas.dax').write_text('\n\n'.join(n+' =\n'+e for n,e,f,d in measures),encoding='utf-8')
(OUT/'powerbi/consulta_snapshot.m').write_text('\n'.join(model['model']['tables'][0]['partitions'][0]['source']['expression']),encoding='utf-8')
(OUT/'.gitignore').write_text('**/.pbi/\n**/cache.abf\n**/localSettings.json\n*.pbix\n__pycache__/\n')
print(json.dumps(summary,ensure_ascii=False,indent=2));print('VISUALS',visual_count)

for f in (OUT/'powerbi/Queimadas.Report/definition/pages').glob('*/visuals/*/visual.json'):
 d=json.loads(f.read_text());v=d['visual'];h=d['position']['height']
 if v['visualType']=='card':
  v['objects']={'labels':[{'properties':{'fontSize':lit('10D' if h<50 and d['position']['y']>800 else '18D' if h<50 else '30D')}}],'categoryLabels':[{'properties':{'show':lit('false')}}]}
  if h<50:v['visualContainerObjects']['title'][0]['properties']['show']=lit('false')
  f.write_text(json.dumps(d,ensure_ascii=False,indent=2))
