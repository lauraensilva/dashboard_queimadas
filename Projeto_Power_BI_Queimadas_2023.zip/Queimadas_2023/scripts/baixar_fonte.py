from pathlib import Path
from urllib.request import urlopen
from io import BytesIO
from zipfile import ZipFile
import hashlib
ROOT = Path(__file__).resolve().parents[1]
URL = "https://dataserver-coids.inpe.br/queimadas/queimadas/focos/csv/anual/Brasil_sat_ref/focos_br_ref_2023.zip"
with urlopen(URL, timeout=120) as resposta:
    pacote = resposta.read()
with ZipFile(BytesIO(pacote)) as z:
    arquivo = z.read("focos_br_ref_2023.csv")
destino = ROOT / "dados" / "originais" / "focos_br_ref_2023.csv"
destino.parent.mkdir(parents=True, exist_ok=True)
destino.write_bytes(arquivo)
print("CSV original salvo:", destino)
print("SHA256:", hashlib.sha256(arquivo).hexdigest())
